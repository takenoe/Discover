package com.example.stock.domain;

import static org.junit.Assert.*;

import org.junit.Test;

public class StockTest {

	@Test
	public void testgetPrice() {
		Stock stock = new Stock(100,150);
		int ans = stock.getQuantity();
		assertEquals(150, ans);
	}
}
