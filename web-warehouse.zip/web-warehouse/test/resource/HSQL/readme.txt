【HSQLの起動】
> cd C:\training\hsqldb\lib
> java -cp hsqldb.jar org.hsqldb.Server -database test

【HSQL Database Managerの起動】
> cd C:\training\hsqldb\lib
> java -cp hsqldb.jar org.hsqldb.util.DatabaseManager

【注意】
ビルドパスをMySQLからHSQLDBのjarを参照するように切り替えてください。