package com.example.goods.util;

import com.example.goods.service.GoodsService;
import com.example.goods.service.GoodsServiceMock;

public class GoodsServiceAndRepositoryFactoryMock {
	public static GoodsService getGoodsService() {
		return new GoodsServiceMock();
	}
}
