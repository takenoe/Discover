﻿package com.example.common.web;

import static com.example.common.constant.SessionConstant.*;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.example.common.constant.WebConstant;
import com.example.common.exception.SystemException;

public abstract class BaseController extends HttpServlet {
	public static final long serialVersionUID = 0;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}

	private void doProcess(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			request.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e) {
			throw new SystemException(e);
		}

		try {
			boolean result = validate(request, response);
			if (result) result = execute(request, response);
			String url = getForwardUrl(result);
			forward(request, response, url);
		} catch (Exception e) {
			e.printStackTrace();
			forward(request, response, WebConstant.ERROR_JSP);
		}
	}

	protected void forward(HttpServletRequest request, HttpServletResponse response, String url)
			throws ServletException, IOException {
		ServletContext sc = getServletContext();
		sc.getRequestDispatcher(url).forward(request, response);
	}

	protected void setErrors(HttpSession session, String message) {
		List<String> errors = new ArrayList<String>();
		errors.add(message);
		session.setAttribute(SESSION_ERRORS, errors);
	}

	protected abstract boolean validate(HttpServletRequest request, HttpServletResponse response);

	protected abstract boolean execute(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException;

	protected abstract String getForwardUrl(boolean b);
}
