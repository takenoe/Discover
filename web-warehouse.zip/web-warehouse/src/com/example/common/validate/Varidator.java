package com.example.common.validate;

import static com.example.common.constant.RuleConstant.*;

import java.util.List;

public class Varidator {

	private static final String WORD = "文字";
	private static final String PARTICLE = "は";
	private static final String UNTIL_UNDER = "以上です。";
	private static final String UNTIL_OVER = "以下です。";

	public static final String GOODS_CODE = "商品コード";
	public static final String GOODS_NAME = "商品名";
	public static final String GOODS_PRICE = "価格";
	public static final String GOODS_QUANTITY = "数量";
	public static final String GOODS_SUBTOTAL = "小計";
	public static final String GOODS_TOTAL = "合計";

	private static final String ERROR_INPUT = "文字列です。";
	private static final String ERROR_INPUT_INT = "数字です。";
	private static final String ERROR_INPUT_STRING_MIN = MIN_STRING + WORD + UNTIL_UNDER;
	private static final String ERROR_INPUT_STRING_MAX = MAX_STRING + WORD + UNTIL_OVER;
	private static final String ERROR_INPUT_QUANTITY_MIN = MIN_QUANTITY + UNTIL_UNDER;
	private static final String ERROR_INPUT_QUANTITY_MAX = MAX_QUANTITY + UNTIL_OVER;
	private static final String ERROR_INPUT_PRICE_MIN = MIN_PRICE + UNTIL_UNDER;
	private static final String ERROR_INPUT_PRICE_MAX = MAX_PRICE + UNTIL_OVER;
	private static final String ERROR_INPUT_GOODS_CODE_MIN = MIN_PRICE + UNTIL_UNDER;
	private static final String ERROR_INPUT_GOODS_CODE_MAX = MAX_PRICE + UNTIL_OVER;

	public static List<String> validateGoodsName(String goodsName, List<String> errors) {
		if (goodsName == null) {
			errors.add(GOODS_NAME + PARTICLE + ERROR_INPUT);
		} else if (goodsName.length() < MIN_STRING) {
			errors.add(GOODS_NAME + PARTICLE + ERROR_INPUT_STRING_MIN);
		} else if (goodsName.length() > MAX_STRING) {
			errors.add(GOODS_NAME + PARTICLE + ERROR_INPUT_STRING_MAX);
		}
		return errors;
	}

	public static List<String> validateGoodsCode(String goodsCode, List<String> errors) {
		try {
			int ans = Integer.parseInt(goodsCode);
			if (ans < MIN_GOODS_CODE) {
				errors.add(GOODS_CODE + PARTICLE + ERROR_INPUT_GOODS_CODE_MIN);
			} else if (ans > MAX_GOODS_CODE) {
				errors.add(GOODS_CODE + PARTICLE + ERROR_INPUT_GOODS_CODE_MAX);
			}
		} catch (NumberFormatException e) {
			errors.add(GOODS_CODE + PARTICLE + ERROR_INPUT_INT);
		}
		return errors;
	}

	public static List<String> validatePrice(String price, List<String> errors) {
		try {
			int ans = Integer.parseInt(price);
			if (ans < MIN_PRICE) {
				errors.add(GOODS_PRICE + PARTICLE + ERROR_INPUT_PRICE_MIN);
			} else if (ans < MIN_PRICE || ans > MAX_PRICE) {
				errors.add(GOODS_PRICE + PARTICLE + ERROR_INPUT_PRICE_MAX);
			}
		} catch (NumberFormatException e) {
			errors.add(GOODS_PRICE + PARTICLE + ERROR_INPUT_INT);
		}
		return errors;
	}

	public static List<String> validateQuantity(String quantity, List<String> errors) {
		try {
			int ans = Integer.parseInt(quantity);
			if (ans < MIN_QUANTITY) {
				errors.add(GOODS_QUANTITY + PARTICLE + ERROR_INPUT_QUANTITY_MIN);
			} else if (ans > MAX_QUANTITY) {
				errors.add(GOODS_QUANTITY + PARTICLE + ERROR_INPUT_QUANTITY_MAX);
			}
		} catch (NumberFormatException e) {
			errors.add(GOODS_QUANTITY + PARTICLE + ERROR_INPUT_INT);
		}
		return errors;
	}
}
