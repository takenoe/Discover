package com.example.common.constant;

public class RequestConstant {
	public static final String REQUEST_GODDS_CODE = "code";
	public static final String REQUEST_GODDS_NAME = "name";
	public static final String REQUEST_GODDS_PRICE = "price";
	public static final String REQUEST_STOCK_QUANTITY = "quantity";
}

