package com.example.common.constant;

public class DataConstant {
	public static final String CURRENCY = "¥";
	public static final String STATUS = "STATUS";
	public static final String STATUS_ACTIVE = "ACTIVE";
	public static final String STATUS_DEACTIVE = "DEACTIVE";
}

