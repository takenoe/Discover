package com.example.common.constant;

public class WebConstant {
	public static final String ERROR_JSP = "/WEB-INF/jsp/error.jsp";

	public static final String GOODS_MENU_REQUEST = "/goods";
	public static final String GOODS_MENU_JSP = "/WEB-INF/jsp/goods/goods_menu.jsp";

	public static final String GOODS_CREATE_INPUT_REQUEST = "/goods/create/input";
	public static final String GOODS_CREATE_CONFIRM_REQUEST = "/goods/create/confirm";
	public static final String GOODS_CREATE_COMPLETE_REQUEST = "/goods/create/complete";

	public static final String GOODS_LIST_REQUEST = "/goods/list";

	public static final String GOODS_FIND_INPUT_REQUEST = "/goods/find/input";
	public static final String GOODS_FIND_COMPLETE_REQUEST = "/goods/find/complete";

	public static final String GOODS_DELETE_INPUT_REQUEST = "/goods/delete/input";
	public static final String GOODS_DELETE_CONFIRM_REQUEST = "/goods/delete/confirm";
	public static final String GOODS_DELETE_COMPLETE_REQUEST = "/goods/delete/complete";

	public static final String GOODS_CREATE_INPUT_JSP = "/WEB-INF/jsp/goods/goods_create_input.jsp";
	public static final String GOODS_CREATE_CONFIRM_JSP = "/WEB-INF/jsp/goods/goods_create_confirm.jsp";
	public static final String GOODS_CREATE_COMPLETE_JSP = "/WEB-INF/jsp/goods/goods_create_complete.jsp";

	public static final String GOODS_LIST_JSP = "/WEB-INF/jsp/goods/goods_list.jsp";

	public static final String GOODS_FIND_INPUT_JSP = "/WEB-INF/jsp/goods/goods_find_input.jsp";
	public static final String GOODS_FIND_COMPLETE_JSP = "/WEB-INF/jsp/goods/goods_find_complete.jsp";

	public static final String GOODS_DELETE_INPUT_JSP = "/WEB-INF/jsp/goods/goods_delete_input.jsp";
	public static final String GOODS_DELETE_CONFIRM_JSP = "/WEB-INF/jsp/goods/goods_delete_confirm.jsp";
	public static final String GOODS_DELETE_COMPLETE_JSP = "/WEB-INF/jsp/goods/goods_delete_complete.jsp";

	public static final String STOCK_MENU_REQUEST = "/stock";
	public static final String STOCK_MENU_JSP = "/WEB-INF/jsp/stock/stock_menu.jsp";

	public static final String STOCK_CREATE_INPUT_REQUEST = "/stock/create/input";
	public static final String STOCK_CREATE_CONFIRM_REQUEST = "/stock/create/confirm";
	public static final String STOCK_CREATE_COMPLETE_REQUEST = "/stock/create/complete";

	public static final String STOCK_LIST_REQUEST = "/stock/list";

	public static final String STOCK_FIND_INPUT_REQUEST = "/stock/find/input";
	public static final String STOCK_FIND_COMPLETE_REQUEST = "/stock/find/complete";

	public static final String STOCK_DELETE_INPUT_REQUEST = "/stock/delete/input";
	public static final String STOCK_DELETE_CONFIRM_REQUEST = "/stock/delete/confirm";
	public static final String STOCK_DELETE_COMPLETE_REQUEST = "/stock/delete/complete";

	public static final String STOCK_INBOUND_INPUT_REQUEST = "/stock/inbound/input";
	public static final String STOCK_INBOUND_CONFIRM_REQUEST = "/stock/inbound/confirm";
	public static final String STOCK_INBOUND_COMPLETE_REQUEST = "/stock/inbound/complete";

	public static final String STOCK_OUTBOUND_INPUT_REQUEST = "/stock/outbound/input";
	public static final String STOCK_OUTBOUND_CONFIRM_REQUEST = "/stock/outbound/confirm";
	public static final String STOCK_OUTBOUND_COMPLETE_REQUEST = "/stock/outbound/complete";

	public static final String STOCK_CREATE_INPUT_JSP = "/WEB-INF/jsp/stock/stock_create_input.jsp";
	public static final String STOCK_CREATE_CONFIRM_JSP = "/WEB-INF/jsp/stock/stock_create_confirm.jsp";
	public static final String STOCK_CREATE_COMPLETE_JSP = "/WEB-INF/jsp/stock/stock_create_complete.jsp";

	public static final String STOCK_LIST_JSP = "/WEB-INF/jsp/stock/stock_list.jsp";

	public static final String STOCK_FIND_INPUT_JSP = "/WEB-INF/jsp/stock/stock_find_input.jsp";
	public static final String STOCK_FIND_COMPLETE_JSP = "/WEB-INF/jsp/stock/stock_find_complete.jsp";

	public static final String STOCK_DELETE_INPUT_JSP = "/WEB-INF/jsp/stock/stock_delete_input.jsp";
	public static final String STOCK_DELETE_CONFIRM_JSP = "/WEB-INF/jsp/stock/stock_delete_confirm.jsp";
	public static final String STOCK_DELETE_COMPLETE_JSP = "/WEB-INF/jsp/stock/stock_delete_complete.jsp";

	public static final String STOCK_INBOUND_INPUT_JSP = "/WEB-INF/jsp/stock/stock_inbound_input.jsp";
	public static final String STOCK_INBOUND_CONFIRM_JSP = "/WEB-INF/jsp/stock/stock_inbound_confirm.jsp";
	public static final String STOCK_INBOUND_COMPLETE_JSP = "/WEB-INF/jsp/stock/stock_inbound_complete.jsp";

	public static final String STOCK_OUTBOUND_INPUT_JSP = "/WEB-INF/jsp/stock/stock_outbound_input.jsp";
	public static final String STOCK_OUTBOUND_CONFIRM_JSP = "/WEB-INF/jsp/stock/stock_outbound_confirm.jsp";
	public static final String STOCK_OUTBOUND_COMPLETE_JSP = "/WEB-INF/jsp/stock/stock_outbound_complete.jsp";

	public static final String INOUTBOUND_HISTORY_REQUEST = "/inoutbound/history";
	public static final String INOUTBOUND_HISTORY_JSP = "/WEB-INF/jsp/stock/inoutbound_history.jsp";
}

