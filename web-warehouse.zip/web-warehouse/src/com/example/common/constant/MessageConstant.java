package com.example.common.constant;

public class MessageConstant {
	public static final String GOODS_NO_DATA = "該当する商品はありません";
	public static final String GOODS_CODE_DUPULICATE = "商品番号が重複しています";
	public static final String GOODS_CODE_DELETE = "商品は削除されています";

	public static final String STOCK_INBOUND = "入荷";
	public static final String STOCK_OUTBOUND = "出荷";

	public static final String STOCK_OVER = "商品の在庫は既に一杯です";
	public static final String STOCK_UNDER = "商品の在庫がマイナスです";
	public static final String STOCK_NOT_EMPTY = "商品の在庫が残っています";
	public static final String STOCK_NO_DATA = "該当する在庫商品はありません";
	public static final String STOCK_GOODS_CODE_DUPULICATE = "在庫商品の商品番号が重複しています";
	public static final String STOCK_GOODS_CODE_DELETE = "在庫商品は削除されています";

	public static final String INOUTBOUND_NO_DATA = "入出荷の履歴はありません";
}
