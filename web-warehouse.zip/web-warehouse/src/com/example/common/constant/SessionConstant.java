package com.example.common.constant;

public class SessionConstant {
	public static final String SESSION_ERRORS = "errors";

	public static final String SESSION_GODDS = "Goods";
	public static final String SESSION_GODDS_LIST = "GoodsList";

	public static final String SESSION_STOCK = "Stock";
	public static final String SESSION_STOCK_LIST = "StockList";

	public static final String SESSION_STOCK_INOUTBOUND_LINE = "InOutBoundLine";

	public static final String SESSION_INOUTBOUND_HISTORY = "inOutBoundHistory";
}
