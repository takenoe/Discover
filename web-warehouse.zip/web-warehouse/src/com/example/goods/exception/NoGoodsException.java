package com.example.goods.exception;

public class NoGoodsException extends Exception {
	private static final long serialVersionUID = 1L;
}
