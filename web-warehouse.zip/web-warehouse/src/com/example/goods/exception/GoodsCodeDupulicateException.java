package com.example.goods.exception;

public class GoodsCodeDupulicateException extends Exception {
	private static final long serialVersionUID = 1L;
}
