package com.example.goods.web;

import static com.example.common.constant.WebConstant.*;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(GOODS_DELETE_INPUT_REQUEST)
public class GoodsDeleteInput extends GoodsBaseController {
	static final long serialVersionUID = 0;

	protected boolean validate(HttpServletRequest request, HttpServletResponse response) {
		return true;
	}

	protected boolean execute(HttpServletRequest request, HttpServletResponse response) {
		return true;
	}

	protected String getForwardUrl(boolean b) {
		return GOODS_DELETE_INPUT_JSP;
	}
}
