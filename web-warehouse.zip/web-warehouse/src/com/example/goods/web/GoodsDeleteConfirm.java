package com.example.goods.web;

import static com.example.common.constant.MessageConstant.*;
import static com.example.common.constant.RequestConstant.*;
import static com.example.common.constant.SessionConstant.*;
import static com.example.common.constant.WebConstant.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.example.common.validate.Varidator;
import com.example.goods.domain.Goods;
import com.example.goods.exception.NoGoodsException;

@WebServlet(GOODS_DELETE_CONFIRM_REQUEST)
public class GoodsDeleteConfirm extends GoodsBaseController {
	static final long serialVersionUID = 0;

	@Override
	protected boolean validate(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession(true);

		List<String> errors = new ArrayList<String>();
		errors = Varidator.validateGoodsCode(request.getParameter(REQUEST_GODDS_CODE), errors);

		session.setAttribute(SESSION_ERRORS, errors);

		if (!errors.isEmpty()) 	return false;
		else return true;
	}

	@Override
	protected boolean execute(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException {
		HttpSession session = request.getSession(true);
        int goodsCode = Integer.parseInt(request.getParameter(REQUEST_GODDS_CODE));

		try {
			if(goodsService.isGoodsDeactive(goodsCode)) {
				setErrors(session, GOODS_CODE_DELETE);
				return false;
			}
			Goods goods = goodsService.findGoods(goodsCode);
			session.setAttribute(SESSION_GODDS, goods);
		} catch (NoGoodsException e) {
			setErrors(session, GOODS_NO_DATA);
			return false;
		}
		return true;
	}

	@Override
	protected String getForwardUrl(boolean b) {
		if(b) return GOODS_DELETE_CONFIRM_JSP;
		else return GOODS_DELETE_INPUT_JSP;
	}
}
