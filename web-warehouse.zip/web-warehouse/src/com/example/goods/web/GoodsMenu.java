package com.example.goods.web;

import static com.example.common.constant.WebConstant.*;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(GOODS_MENU_REQUEST)
public class GoodsMenu extends GoodsBaseController {
	static final long serialVersionUID = 0;

	protected boolean validate(HttpServletRequest request, HttpServletResponse response) {
		return true;
	}

	protected boolean execute(HttpServletRequest request, HttpServletResponse response) {
		return true;
	}

	protected String getForwardUrl(boolean b) {
		return GOODS_MENU_JSP;
	}
}
