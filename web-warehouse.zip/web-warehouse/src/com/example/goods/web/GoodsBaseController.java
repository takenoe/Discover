package com.example.goods.web;

import java.lang.reflect.Method;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import com.example.common.web.BaseController;
import com.example.goods.service.GoodsService;
import com.example.goods.util.GoodsServiceAndRepositoryFactory;

public abstract class GoodsBaseController extends BaseController {
	private static final long serialVersionUID = 1L;
	protected GoodsService goodsService;

	public void init() throws ServletException {
	    ServletContext context = this.getServletContext();
	    String className = context.getInitParameter("GoodsService");
	    // ServiceクラスをMockにする場合は、web.xmlの<param-value>を以下のように変更する。
	    // <param-value>com.example.goods.util.GoodsServiceAndRepositoryFactoryMock</param-value>

	    try {
			@SuppressWarnings("unchecked")
			Class<GoodsServiceAndRepositoryFactory> clazz = (Class<GoodsServiceAndRepositoryFactory>)Class.forName(className);
			Method method;
			method = clazz.getMethod("getGoodsService");
			goodsService = (GoodsService)method.invoke(null);
		} catch (Exception e) {
			throw new ServletException("GoodsServiceクラスの生成失敗");
		}
	}

}
