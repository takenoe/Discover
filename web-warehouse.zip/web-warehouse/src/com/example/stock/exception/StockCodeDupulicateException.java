package com.example.stock.exception;

public class StockCodeDupulicateException extends Exception {
	private static final long serialVersionUID = 1L;
}
