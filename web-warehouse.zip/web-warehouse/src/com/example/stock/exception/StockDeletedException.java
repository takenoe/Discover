package com.example.stock.exception;

public class StockDeletedException extends Exception {
	private static final long serialVersionUID = 1L;
}
