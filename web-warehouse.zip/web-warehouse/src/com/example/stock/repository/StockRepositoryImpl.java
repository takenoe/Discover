package com.example.stock.repository;

import static com.example.common.constant.DataConstant.STATUS_ACTIVE;
import static com.example.common.constant.DataConstant.STATUS_DEACTIVE;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.List;

import com.example.stock.domain.Stock;
import com.example.stock.exception.StockCodeDupulicateException;
import com.example.stock.exception.NoStockException;
import com.example.stock.service.StockRepository;

public class StockRepositoryImpl implements StockRepository {

	private static final String INSERT = "INSERT INTO STOCK(GOODS_CODE, QUANTITY, STATUS) VALUES(?, ?, ?)";
	private static final String SELECT_ALL = "SELECT GOODS_CODE, QUANTITY FROM STOCK WHERE STATUS =?";
	private static final String SELECT_ONE_GOODS = "SELECT GOODS_CODE, QUANTITY FROM STOCK WHERE GOODS_CODE = ? AND STATUS = ?";
	private static final String UPDATE = "UPDATE STOCK SET STATUS = ? WHERE  GOODS_CODE = ? AND STATUS =?";
	private static final String IOUPDATE = "UPDATE STOCK SET QUANTITY = ? WHERE GOODS_CODE = ? AND STATUS = ?";
	@Override
	public void createStock(Connection connection, Stock stock) throws SQLException, StockCodeDupulicateException {
		try (PreparedStatement preparedStatement = connection.prepareStatement(INSERT)) {
			preparedStatement.setInt(1, stock.getCode());
			preparedStatement.setInt(2, stock.getQuantity());
			preparedStatement.setString(3, STATUS_ACTIVE);
			preparedStatement.executeUpdate();
		} catch (SQLIntegrityConstraintViolationException e) {
			throw new StockCodeDupulicateException();
		}
	}

	@Override
	public List<Stock> findAllStock(Connection connection) throws SQLException, NoStockException {
		List<Stock> stockList = null;

		try (PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL)) {
			preparedStatement.setString(1, STATUS_ACTIVE);
			stockList = getStock(preparedStatement);
		}

		if (stockList.isEmpty()) throw new NoStockException();

		return stockList;
	}
	//データベースを読み取り、stockオブジェクトを返す
	public Stock findStock(Connection connection, int stockCode) throws SQLException, NoStockException {
		 //使用変数を宣言
		List<Stock> stockList = null;
		Stock stock = null;
		// SELECT文を実行
		try (PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ONE_GOODS)) {
			preparedStatement.setInt(1, stockCode);
			preparedStatement.setString(2, STATUS_ACTIVE);
			//getStockメソッドを使い、ArrayListにデータベースから抽出した値を挿入
			stockList = getStock(preparedStatement);
			// 該当商品がない場合エラーを投げる
			if (stockList.size() == 0) {
				throw new NoStockException();
			}else{
				//リストをオブジェクトの形に直す
				stock = stockList.get(0);
			}
		}
		return stock;
	}

	@Override
	public void deleteStock(Connection connection, int stockCode) throws SQLException, NoStockException {
		try (PreparedStatement preparedStatement = connection.prepareStatement(UPDATE)) {
			preparedStatement.setString(1, STATUS_DEACTIVE);
			preparedStatement.setInt(2, stockCode);
			preparedStatement.setString(3, STATUS_ACTIVE);
			int count = preparedStatement.executeUpdate();
			if(count == 0) {
				throw new NoStockException();
			}
		}
	}

	@Override
	public boolean isStockDeactive(Connection connection, int stockCode) throws SQLException {
		try (PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ONE_GOODS)) {
			preparedStatement.setInt(1, stockCode);
			preparedStatement.setString(2, STATUS_DEACTIVE);
			List<Stock> stockList = getStock(preparedStatement);

			if (stockList.isEmpty()) return false;
			return true;
		}
	}

	private List<Stock> getStock(PreparedStatement preparedStatement) throws SQLException {
		List<Stock> stockList = new ArrayList<Stock>();

		try (ResultSet resultSet = preparedStatement.executeQuery()) {
			while (resultSet.next()) {
				Stock stock = new Stock(resultSet.getInt(1), resultSet.getInt(2));
				stockList.add(stock);
			}
		}
		return stockList;
	}
	@Override
	public void updateStock(Connection connection, Stock stock) throws SQLException, NoStockException {
		try (PreparedStatement preparedStatement = connection.prepareStatement(IOUPDATE)) {
			preparedStatement.setInt(1, stock.getQuantity());
			preparedStatement.setInt(2, stock.getCode());
			preparedStatement.setString(3, STATUS_ACTIVE);
			int count = preparedStatement.executeUpdate();
			if(count == 0) {
				throw new NoStockException();
			}
		}
	}
}

