package com.example.stock.web;

import java.lang.reflect.Method;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import com.example.common.web.BaseController;
import com.example.goods.service.GoodsService;
import com.example.goods.util.GoodsServiceAndRepositoryFactory;
import com.example.stock.service.StockService;
import com.example.stock.util.StockServiceAndRepositoryFactory;
import com.example.inout.service.InOutService;
import com.example.inout.util.InOutServiceAndRepositoryFactory;

public abstract class StockBaseController extends BaseController {
	private static final long serialVersionUID = 1L;
	protected GoodsService goodsService;
	protected StockService stockService;
	protected InOutService inoutService;

	public void init() throws ServletException {
	    ServletContext context = this.getServletContext();
	    String className1 = context.getInitParameter("GoodsService");
	    String className2 = context.getInitParameter("StockService");
	    String className3 = context.getInitParameter("InOutService");
	    // ServiceクラスをMockにする場合は、web.xmlの<param-value>を以下のように変更する。

	    //修正待ち
	    // <param-value>com.example.goods.util.GoodsServiceAndRepositoryFactoryMock</param-value>

	    try {
	    	//goodsオブジェクトを生成する
			@SuppressWarnings("unchecked")
			Class<GoodsServiceAndRepositoryFactory> clazz1 = (Class<GoodsServiceAndRepositoryFactory>)Class.forName(className1);
			Method method1;
			method1 = clazz1.getMethod("getGoodsService");
			goodsService = (GoodsService)method1.invoke(null);
		} catch (Exception e) {
			throw new ServletException("GoodsServiceクラスの生成失敗");
		}

	    try {
			//stockオブジェクトを生成する
			@SuppressWarnings("unchecked")
			Class<StockServiceAndRepositoryFactory> clazz2 = (Class<StockServiceAndRepositoryFactory>)Class.forName(className2);
			Method method2;
			method2 = clazz2.getMethod("getStockService");
			stockService = (StockService)method2.invoke(null);
		} catch (Exception e) {
			throw new ServletException("StockServiceクラスの生成失敗");
		}

	    try {
			//inoutオブジェクトを生成する
			@SuppressWarnings("unchecked")
			Class<InOutServiceAndRepositoryFactory> clazz3 = (Class<InOutServiceAndRepositoryFactory>)Class.forName(className3);
			Method method3;
			method3 = clazz3.getMethod("getInOutService");
			inoutService = (InOutService)method3.invoke(null);
		} catch (Exception e) {
			throw new ServletException("InOutServiceクラスの生成失敗");
		}
	}

}
