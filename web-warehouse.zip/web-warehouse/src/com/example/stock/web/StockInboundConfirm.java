package com.example.stock.web;


import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import static com.example.common.constant.MessageConstant.*;
import static com.example.common.constant.RequestConstant.*;
import static com.example.common.constant.WebConstant.*;
import static com.example.common.constant.SessionConstant.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.example.common.validate.Varidator;
import com.example.stock.domain.Stock;
import com.example.inout.domain.InOut;
import com.example.stock.exception.NoStockException;



@WebServlet(STOCK_INBOUND_CONFIRM_REQUEST)
public class StockInboundConfirm extends StockBaseController {
	private static final long serialVersionUID = 0;

	@Override
	protected boolean validate(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession(true);
		//エラーを入れるリストを作る
		List<String> errors = new ArrayList<String>();
		//入力値のエラーチェック
		errors = Varidator.validateGoodsCode(request.getParameter(REQUEST_GODDS_CODE), errors);
		errors = Varidator.validateQuantity(request.getParameter(REQUEST_STOCK_QUANTITY), errors);
		//リストにエラーをセット
		session.setAttribute(SESSION_ERRORS, errors);
		//エラーリストが空ならエグゼキュートへ
		if (!errors.isEmpty()) 	return false;
		else return true;
	}
	@Override
	protected boolean execute(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException,SQLException{
		//セッションを生成
		HttpSession session =request.getSession(true);
		//入力された値を取り出す
		int code =Integer.parseInt(request.getParameter(REQUEST_GODDS_CODE));
		int quantity = Integer.parseInt(request.getParameter(REQUEST_STOCK_QUANTITY));
		Stock stock =null;
		InOut inout = new InOut("入荷", code, quantity);
		int total = 0;
		try{
			//検索する
			stock = (Stock)stockService.findStock(code);
			if(stockService.isStockDeactive(code)){
				setErrors(session, STOCK_GOODS_CODE_DELETE);
				return false;
			}
			//該当する商品がない
		}catch(NoStockException e){
			setErrors(session,STOCK_NO_DATA);
			return false;
		}catch(ClassNotFoundException | SQLException e){
			setErrors(session,"SQLが違うORクラスが見つからない");
			return false;
		}catch(Exception e){
			//未知のエラー
			System.out.println("未知のエラー:" + e.getMessage());
			e.printStackTrace();
			setErrors(session, "未知のエラー");
			return false;
		}
		total = stock.getQuantity() + inout.getQuantity();
		if(total > 100){
			//在庫数が100より大きくなる時のエラー
			setErrors(session, STOCK_OVER);
			return false;
		}
		stock.setQuantity(total);

		//セッションに”Stock””InOut”の要素を入れる
		session.setAttribute(SESSION_STOCK,stock);
		session.setAttribute(SESSION_STOCK_INOUTBOUND_LINE, inout);
		return true;
	}
	@Override
	protected String getForwardUrl(boolean b){
		//成功
		if(b)return STOCK_INBOUND_CONFIRM_JSP;
		//エラーがあったら
		else return STOCK_INBOUND_INPUT_JSP;

	}

}
