package com.example.stock.web;

import static com.example.common.constant.WebConstant.*;


import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.example.stock.web.StockBaseController;


@WebServlet(STOCK_OUTBOUND_INPUT_REQUEST)
public class StockOutboundInput extends StockBaseController {
	static final long serialVersionUID = 0;


	protected boolean validate(HttpServletRequest request, HttpServletResponse response){
		return true;
	}

	protected boolean execute(HttpServletRequest request, HttpServletResponse response){
		return true;
	}
	protected String getForwardUrl(boolean b){
		return STOCK_OUTBOUND_INPUT_JSP ;
	}
}