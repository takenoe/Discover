package com.example.stock.web;

import static com.example.common.constant.MessageConstant.*;
import static com.example.common.constant.SessionConstant.*;
import static com.example.common.constant.WebConstant.*;

import java.sql.SQLException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.example.inout.domain.InOut;
import com.example.stock.domain.Stock;
import com.example.stock.exception.NoStockException;
import com.example.stock.exception.StockDeletedException;
import com.example.stock.web.StockBaseController;

@WebServlet(STOCK_OUTBOUND_COMPLETE_REQUEST)
public class StockOutboundComplete extends StockBaseController {
	static final long serialVersionUID = 0;

	@Override
	protected boolean validate(HttpServletRequest request, HttpServletResponse response) {
		return true;
	}

    @Override
    public boolean execute(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, SQLException {
        HttpSession session = request.getSession(true);
        Stock stock = (Stock) session.getAttribute(SESSION_STOCK);
        InOut inout = (InOut) session.getAttribute(SESSION_STOCK_INOUTBOUND_LINE);

		try {
			stockService.updateStock(stock);

		} catch (NoStockException e){
			setErrors(session, STOCK_NO_DATA);
			return false;
		} catch (StockDeletedException e) {
			setErrors(session, STOCK_GOODS_CODE_DELETE);
			return false;
		}

		try{
			inoutService.createInOut(inout);

		}catch (SQLException e) {
			System.out.println(e.getMessage());
			return false;
		}
		//セッションに格納する
		session.setAttribute(SESSION_STOCK, stock);
		session.setAttribute(SESSION_STOCK_INOUTBOUND_LINE,inout);
		return true;
    }

	@Override
	protected String getForwardUrl(boolean b) {
		if(b) return STOCK_OUTBOUND_COMPLETE_JSP;
		else return STOCK_OUTBOUND_INPUT_JSP;
	}
}