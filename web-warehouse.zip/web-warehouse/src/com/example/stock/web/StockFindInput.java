


package com.example.stock.web;

import static com.example.common.constant.WebConstant.*;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(STOCK_FIND_INPUT_REQUEST)
public class StockFindInput extends StockBaseController{
	//不明
	static final long serialVersionUID = 0;

	protected boolean validate(HttpServletRequest request, HttpServletResponse response){
		return true;
	}

	protected boolean execute(HttpServletRequest request,HttpServletResponse response){
		return true;
	}

	protected String getForwardUrl(boolean b){
		return STOCK_FIND_INPUT_JSP;
	}


}



