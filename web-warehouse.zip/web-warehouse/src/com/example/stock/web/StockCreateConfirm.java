package com.example.stock.web;

import static com.example.common.constant.MessageConstant.*;
import static com.example.common.constant.RequestConstant.*;
import static com.example.common.constant.SessionConstant.*;
import static com.example.common.constant.WebConstant.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.example.common.validate.Varidator;
import com.example.goods.exception.NoGoodsException;
import com.example.stock.domain.Stock;
import com.example.stock.exception.StockCodeDupulicateException;

@WebServlet(STOCK_CREATE_CONFIRM_REQUEST)
public class StockCreateConfirm extends StockBaseController {
	static final long serialVersionUID = 0;

	@Override
	protected boolean validate(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession(true);
		//エラーを入れるリストを作る
		List<String> errors = new ArrayList<String>();
		//入力値のエラーチェック
		errors = Varidator.validateGoodsCode(request.getParameter(REQUEST_GODDS_CODE), errors);
		//リストにエラーをセット
		session.setAttribute(SESSION_ERRORS, errors);
		//エラーリストが空ならエグゼキュートへ
		if (!errors.isEmpty()) 	return false;
		else return true;
	}

	@Override
	protected boolean execute(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException {
		HttpSession session = request.getSession(true);

		//標準入力からコードを取り出す
		int code = Integer.parseInt(request.getParameter(REQUEST_GODDS_CODE));

        //商品テーブルを参照
        try{
        	goodsService.findGoods(code);
        //入力コードと同じactiveな商品コードがない場合エラー処理を行う
        }catch(NoGoodsException e){
			setErrors(session,GOODS_NO_DATA);
			return false;
        }
		//入力コードと同じdeactiveな(削除された)商品コードがある場合エラー処理を行う
        if(goodsService.isGoodsDeactive(code)){
			setErrors(session,GOODS_NO_DATA);
			return false;
        }
        //倉庫テーブルを参照
		try {
			if(!stockService.isStockCreate(code)) {
				//入力コードが在庫テーブルで削除されている場合
				setErrors(session, STOCK_GOODS_CODE_DELETE);
				return false;
			}
		//入力コードがすでに倉庫テーブルに登録されている場合
		} catch (StockCodeDupulicateException e) {
			setErrors(session, STOCK_GOODS_CODE_DUPULICATE);
			return false;
		}
		//セッションに入力データを登録
		int quantity = 0;
		Stock stock = new Stock(code, quantity);
		session.setAttribute(SESSION_STOCK, stock);
		return true;
	}

	@Override
	protected String getForwardUrl(boolean b) {
		//エラーの有無によってフォワード先を変更
		if(b) return STOCK_CREATE_CONFIRM_JSP;
		else return STOCK_CREATE_INPUT_JSP;
	}
}
