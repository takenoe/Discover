package com.example.stock.web;


import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import static com.example.common.constant.MessageConstant.*;
import static com.example.common.constant.RequestConstant.*;
import static com.example.common.constant.WebConstant.*;
import static com.example.common.constant.SessionConstant.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.example.common.validate.Varidator;
import com.example.stock.domain.Stock;
import com.example.stock.exception.NoStockException;


@WebServlet(STOCK_FIND_COMPLETE_REQUEST)
public class StockFindComplete extends StockBaseController {
	//不明
	private static final long serialVersionUID = 0;


	protected boolean validate(HttpServletRequest request, HttpServletResponse response)  {
		//セッションを生成
		HttpSession session = request.getSession(true);

		List<String> errors = new ArrayList<String>();
		//コードに関するエラーをつくる
		errors = Varidator.validateGoodsCode(request.getParameter(REQUEST_GODDS_CODE), errors);
		//セッションにエラーを入れる
		session.setAttribute(SESSION_ERRORS, errors);

		//エラーがなかったらtrue
		if (!errors.isEmpty()) 	return false;
		else return true;
	}


	protected boolean execute(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException,SQLException{
		//セッションを生成
		HttpSession session =request.getSession(true);

		//入力されたコードを取り出す
		String code =request.getParameter(REQUEST_GODDS_CODE);
			int code1 =Integer.parseInt(code);


		Stock stock =null;
		try{
			//検索する
			stock = (Stock)stockService.findStock(code1);

			//該当する商品がない
		}catch(NoStockException e){
			setErrors(session,STOCK_NO_DATA);
			return false;

		}
		//セッションに”Stock”の要素を入れる
		session.setAttribute(SESSION_STOCK,stock);
		return true;
	}

	protected String getForwardUrl(boolean b){
		//成功
		if(b)return STOCK_FIND_COMPLETE_JSP;
		//エラーがあったら
		else return STOCK_FIND_INPUT_JSP;

	}

}
