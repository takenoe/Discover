package com.example.stock.web;

import static com.example.common.constant.MessageConstant.*;
import static com.example.common.constant.RequestConstant.*;
import static com.example.common.constant.SessionConstant.*;
import static com.example.common.constant.WebConstant.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.example.common.validate.Varidator;
import com.example.stock.domain.Stock;
import com.example.stock.exception.NoStockException;

@WebServlet(STOCK_DELETE_CONFIRM_REQUEST)
public class StockDeleteConfirm extends StockBaseController {
	static final long serialVersionUID = 0;


	@Override
	protected boolean validate(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession(true);

		List<String> errors = new ArrayList<String>();
		errors = Varidator.validateGoodsCode(request.getParameter(REQUEST_GODDS_CODE), errors);

		session.setAttribute(SESSION_ERRORS, errors);

		if (!errors.isEmpty()) 	return false;
		else return true;
	}

	@Override
	protected boolean execute(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException {
		HttpSession session = request.getSession(true);
        int stockCode = Integer.parseInt(request.getParameter(REQUEST_GODDS_CODE));


		try {

			if(stockService.isStockDeactive(stockCode)) {
				setErrors(session, STOCK_GOODS_CODE_DELETE);
				return false;
			}

			Stock stock = stockService.findStock(stockCode);
			if(stock.getQuantity() > 0){
				setErrors(session, STOCK_NOT_EMPTY);
				return false;
			}

			session.setAttribute(SESSION_STOCK, stock);
		} catch (NoStockException e) {
			setErrors(session, STOCK_NO_DATA);
			return false;
		}
		return true;
	}

	@Override
	protected String getForwardUrl(boolean b) {
		if(b) return STOCK_DELETE_CONFIRM_JSP;
		else return STOCK_DELETE_INPUT_JSP;
	}
}
