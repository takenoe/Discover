package com.example.stock.service;


import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.example.stock.domain.Stock;
import com.example.stock.exception.StockCodeDupulicateException;
import com.example.stock.exception.NoStockException;

public interface StockRepository {

	void createStock(Connection connection, Stock Stock) throws SQLException, StockCodeDupulicateException;

	List<Stock> findAllStock(Connection connection) throws SQLException, NoStockException;

	Stock findStock(Connection connection, int StockCode) throws SQLException, NoStockException;

	void deleteStock(Connection connection, int StockCode) throws SQLException, NoStockException;

	boolean isStockDeactive(Connection connection, int StockCode) throws SQLException;

	public void updateStock(Connection connection, Stock stock) throws SQLException, NoStockException;
}

