package com.example.stock.service;

import java.sql.SQLException;
import java.util.List;

import com.example.stock.domain.Stock;
import com.example.stock.exception.StockCodeDupulicateException;
import com.example.stock.exception.StockDeletedException;
import com.example.stock.exception.NoStockException;

public interface StockService {

	void createStock(Stock stock) throws SQLException, StockCodeDupulicateException, ClassNotFoundException, StockDeletedException;

	List<Stock> findAllStock() throws SQLException, NoStockException, ClassNotFoundException;

	Stock findStock(int stockCode) throws SQLException, NoStockException, ClassNotFoundException;

	boolean isStockDeactive(int goodsCode) throws SQLException, ClassNotFoundException;

	boolean isStockCreate(int goodsCode) throws SQLException, ClassNotFoundException, StockCodeDupulicateException;

	void deleteStock(int goodsCode) throws SQLException, ClassNotFoundException, NoStockException, StockDeletedException;

	void updateStock(Stock stock) throws SQLException, ClassNotFoundException, NoStockException, StockDeletedException;
}