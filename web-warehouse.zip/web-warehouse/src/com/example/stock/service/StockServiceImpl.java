package com.example.stock.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.example.common.transaction.TransactionManager;
import com.example.stock.domain.Stock;
import com.example.stock.exception.StockCodeDupulicateException;
import com.example.stock.exception.StockDeletedException;
import com.example.stock.exception.NoStockException;

public class StockServiceImpl implements StockService {

	private StockRepository stockRepository;

	public StockServiceImpl(StockRepository stockRepository) {
		this.stockRepository = stockRepository;
	}

	@Override
	public void createStock(Stock stock) throws ClassNotFoundException, SQLException, StockDeletedException, StockCodeDupulicateException {
		try (Connection connection = TransactionManager.getConnection()) {
			try {
				if(stockRepository.isStockDeactive(connection, stock.getCode())) {
					throw new StockDeletedException();
				}
				stockRepository.createStock(connection, stock);
				TransactionManager.commit(connection);
			} catch (Exception e) {
				TransactionManager.rollback(connection);
				throw e;
			}
		}
	}

	@Override
	public List<Stock> findAllStock() throws SQLException, NoStockException, ClassNotFoundException {
		try (Connection connection = TransactionManager.getReadOnlyConnection()) {
			List<Stock> stockList = stockRepository.findAllStock(connection);
			TransactionManager.commit(connection);
			return stockList;
		}
	}

	@Override
	public Stock findStock(int stockCode) throws SQLException, NoStockException, ClassNotFoundException {
		try (Connection connection = TransactionManager.getReadOnlyConnection()) {
		Stock stock = stockRepository.findStock(connection, stockCode);
		TransactionManager.commit(connection);
		return stock;
		}
	}

	@Override
	public void deleteStock(int stockCode) throws SQLException, NoStockException, ClassNotFoundException,StockDeletedException {
		try (Connection connection = TransactionManager.getConnection()) {
			try {
				if(stockRepository.isStockDeactive(connection, stockCode)) {
					throw new StockDeletedException();
				}
				stockRepository.deleteStock(connection, stockCode);
				TransactionManager.commit(connection);
			} catch (Exception e) {
				TransactionManager.rollback(connection);
				throw e;
			}
		}
	}

	@Override
	public boolean isStockDeactive(int stockCode) throws SQLException, ClassNotFoundException {
		try (Connection connection = TransactionManager.getReadOnlyConnection()) {
			return stockRepository.isStockDeactive(connection, stockCode);
		}
	}

	@Override
	public boolean isStockCreate(int stockCode) throws SQLException, ClassNotFoundException, StockCodeDupulicateException {
		try (Connection connection = TransactionManager.getReadOnlyConnection()) {
			try {
				stockRepository.findStock(connection, stockCode);
				throw new StockCodeDupulicateException();
			} catch (NoStockException e) {
				return !stockRepository.isStockDeactive(connection, stockCode);
			}
		}
	}

	@Override
	public void updateStock(Stock stock) throws SQLException, NoStockException, ClassNotFoundException,StockDeletedException {
		try (Connection connection = TransactionManager.getConnection()) {
			try {
				if(stockRepository.isStockDeactive(connection, stock.getCode())) {
					throw new StockDeletedException();
				}
				stockRepository.updateStock(connection, stock);
				TransactionManager.commit(connection);
			} catch (Exception e) {
				TransactionManager.rollback(connection);
				throw e;
			}
		}
	}
}
