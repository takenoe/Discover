package com.example.inout.repository;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.List;

import com.example.inout.domain.InOut;
import com.example.inout.exception.NoInOutException;
import com.example.inout.service.InOutRepository;

public class InOutRepositoryImpl implements InOutRepository {

	private static final String INSERT = "INSERT INTO IN_OUT_LOG(IN_OUT_TYPE, GOODS_CODE, QUANTITY) VALUES(?, ?, ?)";
	private static final String SELECT_ALL = "SELECT * FROM IN_OUT_LOG";
	//private static final String SELECT_ONE_GOODS = "SELECT CODE, NAME, PRICE FROM GOODS WHERE CODE = ? AND STATUS = ?";
	//private static final String UPDATE = "UPDATE GOODS SET STATUS = ? WHERE  CODE = ? AND STATUS =?";

	@Override
	public void createInOut(Connection connection, InOut inout) throws SQLException {
		try (PreparedStatement preparedStatement = connection.prepareStatement(INSERT)) {
			preparedStatement.setString(1, inout.getType());
			preparedStatement.setInt(2, inout.getCode());
			preparedStatement.setInt(3, inout.getQuantity());
			preparedStatement.executeUpdate();
		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println(e.getMessage());
		}
	}

	@Override
	public List<InOut> findAllInOut(Connection connection) throws SQLException, NoInOutException {
		List<InOut> inoutList = null;

		try (PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL)) {
			inoutList = getInOut(preparedStatement);
		}

		if (inoutList.isEmpty()) throw new NoInOutException();
		return inoutList;
	}
	//データベースを読み取り、goodsオブジェクトを返す
	//public InOut findInOut(Connection connection, int goodsCode) throws SQLException, NoInOutException {
		// 使用変数を宣言
		//List<InOut> goodsList = null;
		//InOut goods = null;
		// SELECT文を実行
		//try (PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ONE_INOUT)) {
			//preparedStatement.setInt(1, goodsCode);
			//preparedStatement.setString(2, STATUS_ACTIVE);
			//getInOutメソッドを使い、ArrayListにデータベースから抽出した値を挿入
			//goodsList = getInOut(preparedStatement);
			// 該当商品がない場合エラーを投げる
			//if (goodsList.size() == 0) {
			//	throw new NoInOutException();
			//}else{
				//リストをオブジェクトの形に直す
			//	goods = goodsList.get(0);
			//}
		//}
		//return goods;
	//}

	//@Override
	//public void deleteInOut(Connection connection, int goodsCode) throws SQLException, NoInOutException {
		//try (PreparedStatement preparedStatement = connection.prepareStatement(UPDATE)) {
		//	preparedStatement.setString(1, STATUS_DEACTIVE);
		//	preparedStatement.setInt(2, goodsCode);
		//	preparedStatement.setString(3, STATUS_ACTIVE);
		//	int count = preparedStatement.executeUpdate();
		//	if(count == 0) {
		//		throw new NoInOutException();
		//	}
		//}
	//}

	//@Override
	//public boolean isInOutDeactive(Connection connection, int goodsCode) throws SQLException {
	//	try (PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ONE_GOODS)) {
	//		preparedStatement.setInt(1, goodsCode);
	//		preparedStatement.setString(2, STATUS_DEACTIVE);
	//		List<InOut> goodsList = getInOut(preparedStatement);
//
	//		if (goodsList.isEmpty()) return false;
	//		return true;
	//	}
	//}

	private List<InOut> getInOut(PreparedStatement preparedStatement) throws SQLException {
		List<InOut> inoutList = new ArrayList<InOut>();

		try (ResultSet resultSet = preparedStatement.executeQuery()) {
			while (resultSet.next()) {
				InOut inout = new InOut(resultSet.getInt(1), resultSet.getString(2), resultSet.getInt(3), resultSet.getInt(4));
				inoutList.add(inout);
			}
		}
		return inoutList;
	}
}

