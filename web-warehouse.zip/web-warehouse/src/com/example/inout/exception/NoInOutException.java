package com.example.inout.exception;

public class NoInOutException extends Exception {
	private static final long serialVersionUID = 1L;
}
