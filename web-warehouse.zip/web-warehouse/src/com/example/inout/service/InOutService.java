package com.example.inout.service;

import java.sql.SQLException;
import java.util.List;

import com.example.inout.domain.InOut;
import com.example.inout.exception.NoInOutException;

public interface InOutService {

	void createInOut(InOut inout) throws SQLException, ClassNotFoundException;

	List<InOut> findAllInOut() throws SQLException, ClassNotFoundException, NoInOutException;

	InOut findInOut(int goodsCode) throws SQLException, ClassNotFoundException;

	boolean isInOutDeactive(int goodsCode) throws SQLException, ClassNotFoundException;

	boolean isInOutCreate(int goodsCode) throws SQLException, ClassNotFoundException;

	void deleteInOut(int goodsCode) throws SQLException, ClassNotFoundException;

}