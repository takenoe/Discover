package com.example.inout.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.example.common.transaction.TransactionManager;
import com.example.inout.domain.InOut;
import com.example.inout.exception.NoInOutException;


public class InOutServiceImpl implements InOutService {

	private InOutRepository inoutRepository;
	public InOutServiceImpl(InOutRepository inoutRepository) {
		this.inoutRepository = inoutRepository;
	}

	@Override
	public void createInOut(InOut inout) throws ClassNotFoundException, SQLException {
		try (Connection connection = TransactionManager.getConnection()) {
			try {
				inoutRepository.createInOut(connection, inout);
				TransactionManager.commit(connection);
			} catch (Exception e) {
				TransactionManager.rollback(connection);
				throw e;
			}
		}
	}

	@Override
	public List<InOut> findAllInOut() throws SQLException, ClassNotFoundException, NoInOutException {
		try (Connection connection = TransactionManager.getReadOnlyConnection()) {
			List<InOut> inoutList = inoutRepository.findAllInOut(connection);
			TransactionManager.commit(connection);
			return inoutList;
		}catch(NoInOutException e){
			throw new NoInOutException();
		}
	}

	@Override
	public InOut findInOut(int goodsCode) throws SQLException, ClassNotFoundException {
		//try (Connection connection = TransactionManager.getReadOnlyConnection()) {
		//InOut goods = goodsRepository.findInOut(connection, goodsCode);
		//TransactionManager.commit(connection);
		return null;  //goods;変更
		//}
	}

	@Override
	public void deleteInOut(int goodsCode) throws SQLException, ClassNotFoundException{
		//try (Connection connection = TransactionManager.getConnection()) {
			//try {
				//if(goodsRepository.isInOutDeactive(connection, goodsCode)) {
					//throw new InOutDeletedException();
			//	}
				//goodsRepository.deleteInOut(connection, goodsCode);
				//TransactionManager.commit(connection);
			//} catch (Exception e) {
				//TransactionManager.rollback(connection);
				//throw e;
			//}
		//}
	}

	@Override
	public boolean isInOutDeactive(int goodsCode) throws SQLException, ClassNotFoundException {
		//try (Connection connection = TransactionManager.getReadOnlyConnection()) {
			return true;//goodsRepository.isInOutDeactive(connection, goodsCode);
		//}
	}

	@Override
	public boolean isInOutCreate(int goodsCode) throws SQLException, ClassNotFoundException {
		//try (Connection connection = TransactionManager.getReadOnlyConnection()) {
			//try {
			//	goodsRepository.findInOut(connection, goodsCode);
				//throw new InOutCodeDupulicateException();
			//} catch (NoInOutException e) {
				return true; //!goodsRepository.isInOutDeactive(connection, goodsCode);
			//}
		//}
	}
}
