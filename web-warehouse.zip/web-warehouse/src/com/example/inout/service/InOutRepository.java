package com.example.inout.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.example.inout.domain.InOut;
import com.example.inout.exception.NoInOutException;

public interface InOutRepository {

	void createInOut(Connection connection, InOut inout) throws SQLException;

	List<InOut> findAllInOut(Connection connection) throws SQLException, NoInOutException;

	//InOut findInOut(Connection connection, int inoutCode) throws SQLException;

	//void deleteInOut(Connection connection, int inoutCode) throws SQLException;

	//boolean isInOutDeactive(Connection connection, int inoutCode) throws SQLException;
}
