package com.example.inout.domain;
//import static com.example.common.constant.DataConstant.*;

import java.io.Serializable;

public class InOut implements Serializable {
	private int no;
	private String type;
	private int code;
	private int quantity;

	public InOut(int no, String type, int code, int quantity) {
		this.no = no;
		this.type = type;
		this.code = code;
		this.quantity = quantity;
	}
	public InOut(String type, int code, int quantity){
		this.type = type;
		this.code = code;
		this.quantity = quantity;
	}
	public int getNo(){
		return no;
	}
	public String getType(){
		return type;
	}
	public int getCode() {
		return code;
	}

	public int getQuantity() {
		return quantity;
	}

	//@Override
	//public String toString() {
	//	return "・商品 　商品コード[" + code + "] 商品名[" + name + "] 価格[" + CURRENCY + quantity + "]";
	//}

	//@Override
	//public int hashCode() {
	//	final int prime = 31;
	//	int result = 1;
	//	result = prime * result + code;
	//	result = prime * result + ((name == null) ? 0 : name.hashCode());
	//	result = prime * result + quantity;
	//	return result;
	//}

	//@Override
	//public boolean equals(Object obj) {
	//	if (this == obj) return true;
	//	if (obj == null) return false;
	//	if (getClass() != obj.getClass()) return false;
	//	InOut other = (InOut) obj;
	//	if (code != other.code) return false;
	//	if (name == null) {
	//		if (other.name != null) return false;
	//	} else if (!name.equals(other.name)) return false;
	//	if (quantity != other.quantity) return false;
	//	return true;
	//}

	private static final long serialVersionUID = 1L;
}
