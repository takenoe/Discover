package com.example.inout.util;

import com.example.inout.repository.InOutRepositoryImpl;
import com.example.inout.service.InOutRepository;
import com.example.inout.service.InOutService;
import com.example.inout.service.InOutServiceImpl;

public class InOutServiceAndRepositoryFactory {
	private static final InOutRepository InOutRepository = new InOutRepositoryImpl();
	private static final InOutService InOutService = new InOutServiceImpl(InOutRepository);

	public static InOutService getInOutService() {
		return InOutService;
	}

	public static InOutRepository getInOutRepository() {
		return InOutRepository;
	}
}
