package com.example.stock.web;

import static com.example.common.constant.WebConstant.*;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.example.goods.web.GoodsBaseController;

@WebServlet(STOCK_MENU_REQUEST)
public class StockMenu extends StockBaseController {
	static final long serialVersionUID = 0;

	protected boolean validate(HttpServletRequest request, HttpServletResponse response) {
		return true;
	}

	protected boolean execute(HttpServletRequest request, HttpServletResponse response) {
		return true;
	}

	protected String getForwardUrl(boolean b) {
		return STOCK_MENU_JSP;
	}
}
